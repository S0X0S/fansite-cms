<?php
//  :¨·.·¨:
 //  `·.  Discord : Hasanx ★°*ﾟ
// Hasanxuk Cms★°*ﾟ Edit by Hasanx

?>
<!-- EINDE CONATINER -->
    <script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();   
});
</script>

 <footer id="myFooter">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <h5><?= NOM; ?></h5>
                    <ul>
                        <li><a href="">Bağlantı ortakları</a></li>
                        <li><a href="">Temas etmek</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5>Habbo</h5>
                    <ul>
                        <li><a href="http://www.sulake.com/">Sulake</a></li>
                        <li><a href="">Hayran sitesi politikası</a></li>

                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5>Üyeler</h5>
                    <ul>
                        <li><a href="">Üye Listesi</a></li>
                    </ul>
                </div>
                <div class="col-sm-3 info">
                    <h5>2016 - 2020</h5>
                    <p> Telif hakkı, tüm hakları <?= NOM; ?>'a aittir, biz Habbo veya Sulake üyesi veya parçası değiliz. Habbo Türkiye taraftar sitesi politikasını takip ediyoruz. </p>
                </div>
            </div>
        </div>
        <div class="second-bar">
           <div class="container">
                <h2 class="logo"> <img src="assets/images/HC.png" style="float:left; margin-top:-10px;"> </h2> <h2><?= NOM; ?>, 2016 - 2020</h2>
                <div class="social-icons">
                    <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="google"><i class="fa fa-google-plus"></i></a>
                </div>
            </div>
        </div>
    </footer>
  <script src="assets/js/body.js?wwwwwwwwww"></script>
</body>
</html>
